require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const analyzeRoutes = require("./routes/analyze");
const reportRoutes = require("./routes/report");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/api", analyzeRoutes);
app.use("/api", reportRoutes);

// Serves the read-only shared-report page; report.js on that page fetches
// the actual data from GET /api/report/:id.
app.get("/report/:id", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "report.html"));
});

app.get("/api/health", (req, res) => {
  res.json({
    ok: true,
    hasApiKey: Boolean(process.env.GROQ_API_KEY) && !process.env.GROQ_API_KEY.includes("your_new_groq_key_here")
  });
});

app.listen(PORT, () => {
  console.log(`\nTrooze AI running at http://localhost:${PORT}\n`);
});
