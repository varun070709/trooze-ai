/**
 * Reverse-image analysis is intentionally hidden from the Trooze AI UI.
 * No paid reverse-image API is used.
 */
async function reverseImageSearch() {
  return null;
}

module.exports = { reverseImageSearch };
