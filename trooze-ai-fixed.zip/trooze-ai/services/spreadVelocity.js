const fetch = require("node-fetch");

/**
 * Cross-platform spread graph.
 *
 * Uses the GDELT Project's free Doc API (no key, no signup, no rate-limit
 * paywall for reasonable use) - it indexes worldwide news coverage and can
 * return article volume over time for a search query. A sudden, sharp
 * spike is itself a red flag independent of the article's content, since
 * organic stories usually build up more gradually and unnaturally
 * coordinated pushes tend to burst all at once.
 *
 * Docs: https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/
 */
async function getSpreadData(headline) {
  if (!headline || !headline.trim()) {
    return { mode: "unavailable", reason: "No headline/query text available." };
  }

  try {
    const query = sanitizeQuery(headline);
    const params = new URLSearchParams({
      query,
      mode: "timelinevol", // volume of matching coverage over time
      format: "json",
      timespan: "7d" // last 7 days - good window to catch a burst
    });

    const url = `https://api.gdeltproject.org/api/v2/doc/doc?${params}`;
    const res = await fetch(url, { timeout: 10000 });

    if (!res.ok) {
      return { mode: "unavailable", reason: `GDELT returned status ${res.status}.` };
    }

    const data = await res.json();
    const series = data?.timeline?.[0]?.data || [];

    if (!series.length) {
      return {
        mode: "live",
        totalOutlets: 0,
        points: [],
        note: "No matching coverage found in the last 7 days - either very new, very niche, or the query needs refining."
      };
    }

    const points = series.map((p) => ({
      date: (p.date || "").slice(0, 10),
      // GDELT returns "value" as a percentage of that day's total global
      // monitored volume - we keep it as-is and let the chart scale it.
      count: Number(p.value) || 0
    }));

    return {
      mode: "live",
      totalOutlets: null, // GDELT gives relative volume, not a raw outlet count
      points,
      source: "GDELT Doc 2.0 API (global news volume, % of monitored coverage)"
    };
  } catch (err) {
    return { mode: "unavailable", reason: err.message || "GDELT request failed." };
  }
}

function sanitizeQuery(text) {
  // GDELT's query syntax breaks on very long strings / punctuation-heavy
  // headlines - trim to a short, clean phrase for best results.
  return text
    .replace(/["""]/g, "")
    .split(/\s+/)
    .slice(0, 10)
    .join(" ")
    .slice(0, 150);
}

module.exports = { getSpreadData };
