const fetch = require("node-fetch");

/**
 * Free, keyless Wikipedia search - used to pull background context on the
 * people/organizations/events named in a claim, for the model to compare
 * the article's framing against.
 */
async function searchWikipedia(query, limit = 3) {
  try {
    const searchUrl = `https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(
      query
    )}&format=json&srlimit=${limit}`;
    const res = await fetch(searchUrl, {
      headers: { "User-Agent": "TroozeAI/1.0 (educational project)" }
    });
    if (!res.ok) return [];
    const data = await res.json();
    const hits = data?.query?.search || [];

    const results = await Promise.all(
      hits.map(async (h) => {
        const summary = await getSummary(h.title);
        return {
          title: h.title,
          snippet: stripHtml(h.snippet),
          summary,
          url: `https://en.wikipedia.org/wiki/${encodeURIComponent(
            h.title.replace(/ /g, "_")
          )}`
        };
      })
    );
    return results;
  } catch {
    return [];
  }
}

async function getSummary(title) {
  try {
    const url = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(
      title
    )}`;
    const res = await fetch(url, {
      headers: { "User-Agent": "TroozeAI/1.0 (educational project)" }
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.extract || null;
  } catch {
    return null;
  }
}

function stripHtml(str = "") {
  return str.replace(/<[^>]+>/g, "");
}

module.exports = { searchWikipedia };
