const fetch = require("node-fetch");

const GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";

/**
 * Calls Groq's chat completions endpoint.
 * @param {Array} messages - OpenAI-style message array (supports vision content parts)
 * @param {Object} opts - { model, jsonMode }
 */
async function groqChat(messages, opts = {}) {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey || apiKey.includes("your_new_groq_key_here")) {
    const err = new Error(
      "GROQ_API_KEY is missing. Add your own fresh key to a local .env file (see .env.example)."
    );
    err.code = "NO_API_KEY";
    throw err;
  }

  const body = {
    model: opts.model,
    messages,
    temperature: opts.temperature ?? 0.2,
    max_tokens: opts.maxTokens ?? 2000
  };

  if (opts.jsonMode) {
    body.response_format = { type: "json_object" };
  }

  const res = await fetch(GROQ_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const text = await res.text();
    const err = new Error(`Groq API error (${res.status}): ${text}`);
    err.status = res.status;
    throw err;
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content ?? "";
}

module.exports = { groqChat };
