const { groqChat } = require("./groq");
const { getSnapshotHistory } = require("./wayback");
const { searchWikipedia } = require("./wikipedia");
const { reverseImageSearch } = require("./reverseImage");
const { getSpreadData } = require("./spreadVelocity");

const TEXT_MODEL = process.env.GROQ_TEXT_MODEL || "openai/gpt-oss-120b";
const VISION_MODEL = process.env.GROQ_VISION_MODEL || "qwen/qwen3.6-27b";

const SYSTEM_PROMPT = `You are the analysis core of Trooze AI, a fake-news and truthiness
detection tool. You are rigorous, skeptical, and calibrated - you do not
overclaim certainty, and you distinguish between "false", "misleading",
"lacks evidence", and "true". You always reason about:
1) factual accuracy of the core claims,
2) who benefits (political party, company, stock, individual) if the
   claim is believed, and whether the article shows signs of incentive bias,
3) manipulation techniques (loaded language, missing context, false
   attribution, out-of-context images/stats).

You must respond with ONLY a single JSON object (no markdown fences, no
commentary outside the JSON), matching exactly this shape:

{
  "verdict": "TRUE" | "LIKELY TRUE" | "MIXED" | "LIKELY FALSE" | "FALSE" | "UNVERIFIED",
  "truthScore": <integer 0-100, 100 = fully verified true>,
  "confidence": "low" | "medium" | "high",
  "summary": "<2-3 sentence plain-language explanation of the verdict>",
  "keyClaims": [ { "claim": "...", "assessment": "..." } ],
  "redFlags": ["..."],
  "whoBenefits": {
    "flagged": true | false,
    "parties": ["e.g. Political Party X", "Company Y", "Stock Ticker Z"],
    "explanation": "..."
  },
  "manipulationTechniques": ["..."],
  "supportingOrRefutingSources": [
    { "name": "...", "stance": "supports" | "refutes" | "adds context", "reason": "..." }
  ],
  "reasoningTrace": [
    "<step 1: what you checked first and why>",
    "<step 2: what evidence you weighed next>",
    "<step 3: how you resolved conflicting signals>",
    "<... continue for however many steps your reasoning actually took ...>",
    "<final step: how the steps above add up to the verdict and score>"
  ]
}

The "reasoningTrace" array is the most important part for user trust: write it as a
plain-language walkthrough of your actual reasoning process, in the order you
reasoned through it - not a restatement of the other fields. Each step should be
one short sentence. A user with no background should be able to read the trace
top to bottom and see exactly how you arrived at the verdict, including any
uncertainty or evidence you didn't have.`;

async function analyzeText({ text, sourceUrl }) {
  const wikiTopic = await extractTopicForWikipedia(text);
  const [wiki, wayback] = await Promise.all([
    searchWikipedia(wikiTopic),
    sourceUrl ? getSnapshotHistory(sourceUrl) : Promise.resolve(null)
  ]);

  const contextBlock = buildContextBlock({ wiki, wayback });

  const userPrompt = `ARTICLE / CLAIM TEXT:
"""
${text.slice(0, 6000)}
"""

${contextBlock}

Analyze this and return the JSON object described in your instructions.`;

  const raw = await groqChat(
    [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: userPrompt }
    ],
    { model: TEXT_MODEL, jsonMode: true, maxTokens: 2800 }
  );

  const parsed = safeParseJson(raw);
  const spread = await getSpreadData(extractHeadlineGuess(text));

  return {
    ...parsed,
    wayback,
    wikipediaContext: wiki,
    spread
  };
}

async function analyzeImage({ base64Image, mimeType, sourceUrl, imageUrl }) {
  // Step 1: pull the text/claims out of the article screenshot
  const extractionRaw = await groqChat(
    [
      {
        role: "user",
        content: [
          {
            type: "text",
            text: "Transcribe all visible article text from this image (headline, byline, date, body text). Then on a new line write ONLY the single most check-worthy factual claim as 'MAIN CLAIM: ...'. No other commentary."
          },
          {
            type: "image_url",
            image_url: { url: `data:${mimeType};base64,${base64Image}` }
          }
        ]
      }
    ],
    { model: VISION_MODEL, maxTokens: 1500 }
  );

  // Step 2: also get a short visual description for the reverse-image module
  const visualDescRaw = await groqChat(
    [
      {
        role: "user",
        content: [
          {
            type: "text",
            text: "In one sentence, describe the main photo/visual in this image (subjects, setting, any visible watermark or timestamp) so it can be checked against a reverse image search."
          },
          {
            type: "image_url",
            image_url: { url: `data:${mimeType};base64,${base64Image}` }
          }
        ]
      }
    ],
    { model: VISION_MODEL, maxTokens: 300 }
  );

  const result = await analyzeText({ text: extractionRaw, sourceUrl });
  const reverseImage = await reverseImageSearch({
    imageUrl,
    imageDescription: visualDescRaw
  });

  return {
    ...result,
    extractedText: extractionRaw,
    reverseImage
  };
}

async function extractTopicForWikipedia(text) {
  try {
    const raw = await groqChat(
      [
        {
          role: "user",
          content: `In 3-6 words, give the best Wikipedia search query to find background on the main subject of this text. Reply with ONLY the query, nothing else.\n\n"""${text.slice(
            0,
            1500
          )}"""`
        }
      ],
      { model: TEXT_MODEL, maxTokens: 30, temperature: 0 }
    );
    return raw.trim().replace(/^["']|["']$/g, "");
  } catch {
    return text.slice(0, 60);
  }
}

function extractHeadlineGuess(text) {
  return text.split("\n")[0].slice(0, 120);
}

function buildContextBlock({ wiki, wayback }) {
  let block = "";

  if (wiki && wiki.length) {
    block += "\nBACKGROUND CONTEXT (from Wikipedia, for fact-checking only):\n";
    wiki.forEach((w) => {
      block += `- ${w.title}: ${w.summary || w.snippet}\n`;
    });
  }

  if (wayback) {
    if (wayback.hasHistory) {
      block += `\nPUBLICATION HISTORY (web.archive.org): ${wayback.snapshotCount} snapshots found. `;
      block += `First captured ${wayback.firstCapturedAt}, most recent ${wayback.lastCapturedAt}. `;
      if (wayback.firstText && wayback.lastText) {
        block += `Compare the first and latest captured text below and flag in "redFlags" if the headline or key facts were silently changed:\n`;
        block += `FIRST CAPTURE TEXT: """${wayback.firstText.slice(0, 1500)}"""\n`;
        block += `LATEST CAPTURE TEXT: """${wayback.lastText.slice(0, 1500)}"""\n`;
      }
    } else {
      block += `\nPUBLICATION HISTORY: No Wayback Machine snapshots found for this URL (may be un-archived, or no URL was provided).\n`;
    }
  }

  return block;
}

function safeParseJson(raw) {
  try {
    return JSON.parse(raw);
  } catch {
    // model sometimes wraps in fences despite instructions - strip and retry
    const cleaned = raw.replace(/```json|```/g, "").trim();
    try {
      return JSON.parse(cleaned);
    } catch {
      return {
        verdict: "UNVERIFIED",
        truthScore: 50,
        confidence: "low",
        summary:
          "Trooze AI could not fully parse a structured verdict for this input. Raw model output is included for reference.",
        keyClaims: [],
        redFlags: ["Model response could not be parsed as structured JSON."],
        whoBenefits: { flagged: false, parties: [], explanation: "" },
        manipulationTechniques: [],
        supportingOrRefutingSources: [],
        reasoningTrace: [
          "The model's response could not be parsed into the structured format, so a reasoning trace isn't available for this run."
        ],
        rawModelOutput: raw
      };
    }
  }
}

module.exports = { analyzeText, analyzeImage };
