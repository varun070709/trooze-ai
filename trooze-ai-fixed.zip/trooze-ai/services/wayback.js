const fetch = require("node-fetch");

/**
 * Given an article URL, pulls its Wayback Machine snapshot list (CDX API,
 * free/no key needed) and fetches the earliest + latest capture text so we
 * can diff headline/content and flag silent edits.
 */
async function getSnapshotHistory(url) {
  if (!url) return null;

  const cdxUrl = `https://web.archive.org/cdx/search/cdx?url=${encodeURIComponent(
    url
  )}&output=json&fl=timestamp,original,statuscode&collapse=digest&limit=20`;

  const res = await fetch(cdxUrl);
  if (!res.ok) return null;
  const rows = await res.json();

  if (!Array.isArray(rows) || rows.length < 2) {
    return { hasHistory: false, snapshotCount: 0 };
  }

  const [, ...entries] = rows; // first row is the header
  const first = entries[0];
  const last = entries[entries.length - 1];

  const firstSnapshotUrl = `https://web.archive.org/web/${first[0]}/${url}`;
  const lastSnapshotUrl = `https://web.archive.org/web/${last[0]}/${url}`;

  const [firstText, lastText] = await Promise.all([
    fetchSnapshotText(firstSnapshotUrl),
    fetchSnapshotText(lastSnapshotUrl)
  ]);

  return {
    hasHistory: true,
    snapshotCount: entries.length,
    firstCapturedAt: formatTimestamp(first[0]),
    lastCapturedAt: formatTimestamp(last[0]),
    firstSnapshotUrl,
    lastSnapshotUrl,
    firstText: firstText?.slice(0, 4000) || null,
    lastText: lastText?.slice(0, 4000) || null
  };
}

async function fetchSnapshotText(snapshotUrl) {
  try {
    const res = await fetch(snapshotUrl, { timeout: 10000 });
    if (!res.ok) return null;
    const html = await res.text();
    return stripHtml(html);
  } catch {
    return null;
  }
}

function stripHtml(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function formatTimestamp(ts) {
  // ts format: YYYYMMDDhhmmss
  if (!ts || ts.length < 8) return ts;
  const y = ts.slice(0, 4),
    m = ts.slice(4, 6),
    d = ts.slice(6, 8);
  return `${y}-${m}-${d}`;
}

module.exports = { getSnapshotHistory };
