const PDFDocument = require("pdfkit");

const TRUTH_GREEN = "#00a878";
const FAKE_RED = "#d13655";
const CAUTION_AMBER = "#c98300";
const MUTED = "#666666";
const INK = "#111111";

function verdictColor(verdict = "") {
  const v = verdict.toUpperCase();
  if (v.includes("TRUE")) return TRUTH_GREEN;
  if (v.includes("FALSE")) return FAKE_RED;
  return CAUTION_AMBER;
}

/**
 * Builds a PDF report from an analysis result object and returns it as a
 * Buffer. Kept deliberately plain/readable rather than trying to mirror
 * the dashboard UI pixel-for-pixel - PDFs are for printing/forwarding.
 */
function generatePdfBuffer(data) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ margin: 50, size: "A4" });
    const chunks = [];
    doc.on("data", (c) => chunks.push(c));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);

    // --- Header ---
    doc.fontSize(20).fillColor(INK).font("Helvetica-Bold").text("TROOZE AI", { continued: true });
    doc.fontSize(11).fillColor(MUTED).font("Helvetica").text("  Truth Detection Report");
    doc.moveDown(0.3);
    doc
      .fontSize(9)
      .fillColor(MUTED)
      .text(`Generated ${new Date().toLocaleString()}`);
    doc.moveDown(1);
    drawRule(doc);
    doc.moveDown(0.8);

    // --- Verdict block ---
    const vColor = verdictColor(data.verdict);
    doc.fontSize(22).font("Helvetica-Bold").fillColor(vColor).text(data.verdict || "UNVERIFIED");
    doc
      .fontSize(11)
      .font("Helvetica")
      .fillColor(INK)
      .text(`Truth score: ${data.truthScore ?? "N/A"} / 100    ·    Confidence: ${data.confidence || "n/a"}`);
    doc.moveDown(0.6);
    doc.fontSize(11).fillColor(INK).font("Helvetica").text(data.summary || "", { align: "left" });
    doc.moveDown(1);

    // --- Reasoning trace ---
    section(doc, "Why This Score — Reasoning Trace");
    if (data.reasoningTrace && data.reasoningTrace.length) {
      data.reasoningTrace.forEach((step, i) => {
        doc
          .fontSize(10.5)
          .font("Helvetica-Bold")
          .fillColor(INK)
          .text(`${i + 1}. `, { continued: true })
          .font("Helvetica")
          .text(step);
        doc.moveDown(0.25);
      });
    } else {
      emptyNote(doc, "No reasoning trace available for this report.");
    }
    doc.moveDown(0.6);

    // --- Key claims ---
    section(doc, "Key Claims Checked");
    if (data.keyClaims && data.keyClaims.length) {
      data.keyClaims.forEach((c) => {
        doc.fontSize(10.5).font("Helvetica-Bold").fillColor(INK).text(c.claim);
        doc.fontSize(10).font("Helvetica").fillColor(MUTED).text(c.assessment);
        doc.moveDown(0.4);
      });
    } else {
      emptyNote(doc, "No individual claims were separately assessed.");
    }
    doc.moveDown(0.4);

    // --- Red flags & manipulation ---
    twoColumnTags(doc, "Red Flags", data.redFlags, FAKE_RED);
    twoColumnTags(doc, "Manipulation Techniques", data.manipulationTechniques, CAUTION_AMBER);

    // --- Who benefits ---
    section(doc, "Who Benefits / Incentive Bias");
    if (data.whoBenefits && data.whoBenefits.flagged) {
      doc
        .fontSize(10.5)
        .font("Helvetica-Bold")
        .fillColor(INK)
        .text((data.whoBenefits.parties || []).join(", "));
      doc.fontSize(10).font("Helvetica").fillColor(MUTED).text(data.whoBenefits.explanation || "");
    } else {
      emptyNote(doc, "No clear conflict-of-interest pattern detected.");
    }
    doc.moveDown(0.6);

    // --- Sources ---
    section(doc, "Supporting / Refuting Sources");
    if (data.supportingOrRefutingSources && data.supportingOrRefutingSources.length) {
      data.supportingOrRefutingSources.forEach((s) => {
        doc
          .fontSize(10.5)
          .font("Helvetica-Bold")
          .fillColor(INK)
          .text(`${s.name}  `, { continued: true })
          .font("Helvetica")
          .fillColor(MUTED)
          .text(`[${s.stance}]`);
        if (s.reason) doc.fontSize(10).font("Helvetica").fillColor(MUTED).text(s.reason);
        doc.moveDown(0.3);
      });
    } else {
      emptyNote(doc, "No sources were listed.");
    }
    doc.moveDown(0.6);

    // --- Wayback / edit history ---
    section(doc, "Edit History (web.archive.org)");
    if (data.wayback && data.wayback.hasHistory) {
      doc
        .fontSize(10)
        .font("Helvetica")
        .fillColor(INK)
        .text(
          `${data.wayback.snapshotCount} snapshot(s) found. First captured ${data.wayback.firstCapturedAt}, most recent ${data.wayback.lastCapturedAt}.`
        );
    } else {
      emptyNote(doc, "No article URL was provided, or no archived snapshots exist yet.");
    }
    doc.moveDown(0.6);

    // --- Spread velocity ---
    section(doc, "Spread Velocity");
    if (data.spread && data.spread.mode === "live" && data.spread.points && data.spread.points.length) {
      const peak = data.spread.points.reduce((a, b) => (b.count > a.count ? b : a), data.spread.points[0]);
      doc
        .fontSize(10)
        .font("Helvetica")
        .fillColor(INK)
        .text(`Global news coverage volume (GDELT), last 7 days. Peak: ${peak.date} (${peak.count.toFixed(2)}%).`);
    } else {
      emptyNote(doc, "Live spread data was not available for this query.");
    }
    doc.moveDown(0.6);

    // --- Reverse image ---
    if (data.reverseImage) {
      section(doc, "Reverse Image Search");
      if (data.reverseImage.mode === "live") {
        doc
          .fontSize(10)
          .font("Helvetica")
          .fillColor(INK)
          .text(`Earliest known appearance: ${data.reverseImage.earliestKnownAppearance}`);
      } else {
        emptyNote(doc, data.reverseImage.note || "Reverse image search ran in estimated mode.");
      }
      doc.moveDown(0.6);
    }

    // --- Footer ---
    doc.moveDown(0.8);
    drawRule(doc);
    doc.moveDown(0.4);
    doc
      .fontSize(8.5)
      .font("Helvetica-Oblique")
      .fillColor(MUTED)
      .text(
        "Trooze AI is a decision-support tool, not a final authority. Cross-check important claims yourself before acting on this report.",
        { align: "center" }
      );

    doc.end();
  });
}

function section(doc, title) {
  doc.fontSize(12).font("Helvetica-Bold").fillColor(INK).text(title);
  doc.moveDown(0.3);
}

function emptyNote(doc, text) {
  doc.fontSize(10).font("Helvetica-Oblique").fillColor(MUTED).text(text);
  doc.moveDown(0.4);
}

function twoColumnTags(doc, title, items, color) {
  section(doc, title);
  if (items && items.length) {
    doc
      .fontSize(10)
      .font("Helvetica")
      .fillColor(color)
      .text(items.map((i) => `• ${i}`).join("\n"));
  } else {
    emptyNote(doc, "None flagged.");
  }
  doc.moveDown(0.6);
}

function drawRule(doc) {
  const y = doc.y;
  doc
    .strokeColor("#cccccc")
    .lineWidth(0.5)
    .moveTo(doc.page.margins.left, y)
    .lineTo(doc.page.width - doc.page.margins.right, y)
    .stroke();
}

module.exports = { generatePdfBuffer };
