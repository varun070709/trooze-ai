const crypto = require("crypto");

// Simple in-memory store: fine for local/dev use and small deployments.
// Reports expire after 7 days and are pruned lazily on each save.
// NOTE: this resets whenever the server restarts. For a production
// deployment you'd swap this for a real database (e.g. SQLite/Postgres/Redis)
// but that's outside the scope of a local VS Code project.
const store = new Map();
const TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days

function save(data) {
  pruneExpired();
  const id = crypto.randomBytes(5).toString("hex"); // short, URL-friendly
  store.set(id, { data, expiresAt: Date.now() + TTL_MS });
  return id;
}

function get(id) {
  const entry = store.get(id);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    store.delete(id);
    return null;
  }
  return entry.data;
}

function pruneExpired() {
  const now = Date.now();
  for (const [id, entry] of store.entries()) {
    if (now > entry.expiresAt) store.delete(id);
  }
}

module.exports = { save, get };
