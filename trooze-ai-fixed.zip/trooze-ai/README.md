# Trooze AI — Truth Detection Console

A fake-news / truthiness checker. Paste article text or upload a photo of
an article, and it returns a verdict, truth score, key-claim breakdown,
"who benefits" incentive-bias flag, edit-history check, and a spread
graph.

## 1. Setup in VS Code

```bash
cd trooze-ai
npm install
cp .env.example .env
```

Open `.env` and paste in your **own fresh Groq API key** (get one at
console.groq.com/keys — never reuse a key you've pasted into a chat
anywhere, always rotate it first):

```
GROQ_API_KEY=gsk_your_real_key_here
```

Then run it:

```bash
npm start
```

Open **http://localhost:3000** in your browser.

## 2. What's real vs. estimated (read this — it matters)

Your Groq key alone can power an LLM that reasons very well, but it
can't independently browse the live web or query Google/Bing's reverse
image index — those are separate, usually paid, third-party services.
So the app is built with an honest split:

| Feature | Status with just GROQ_API_KEY | To make it fully live |
|---|---|---|
| Text/claim analysis, verdict, truth score | ✅ Real (Groq LLM) | — |
| Image → article text extraction | ✅ Real (Groq vision model) | — |
| Wikipedia background context | ✅ Real, free, no key needed | — |
| **Edit-history check** (web.archive.org) | ✅ Real, free, no key needed | — |
| **Who benefits / conflict-of-interest flag** | ✅ Real (LLM reasoning over the text) | — |
| **Reverse image search + earliest appearance date** | ⚠️ Assisted manual mode: gives you a visual description + one-click, pre-filled Google Lens/TinEye links to check yourself | No automated option - see note below |
| **Spread velocity graph** | ✅ Real, free, no key needed — powered by the [GDELT Project](https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/)'s Doc 2.0 API, which tracks global news coverage volume in near real time | — |

Every card in the UI is labeled **LIVE** or **ESTIMATED** so you always
know which is which — nothing pretends to be live data when it isn't.

**Note on reverse image search:** real Google/Bing reverse image search
(the kind that returns "earliest known appearance" automatically) only
exists behind paid third-party APIs (SerpApi, Bright Data, etc.) - there's
no free, keyless version of this. So this app intentionally skips wiring
one up and instead does the next best thing for free: it describes the
image and hands you a pre-filled Google Lens / TinEye link, one click
away from checking it yourself.

## 3. New: Reasoning Trace + Sharing

**Why This Score — Reasoning Trace**: every analysis now includes a
step-by-step walkthrough of how the model actually reasoned to its
verdict (what it checked first, what evidence it weighed, how it
resolved conflicts). It's real - it comes straight from the Groq call,
not a canned template - so if the model's logic seems off on a given
run, the trace will show you exactly where.

**Export PDF**: click "Export PDF" on any result to download a clean,
printable report (verdict, score, full reasoning trace, claims, red
flags, sources, etc.) - built with `pdfkit`, no external service.

**Copy share link**: click "Copy share link" to save the result and get
a `/report/:id` URL you can send to anyone - they'll see a read-only
version of the report (no server access needed on their end). Links
expire after 7 days. This uses a simple in-memory store, so **links
reset if you restart the server** - fine for local use or a small
deployment; swap `services/reportStore.js` for a real database if you
deploy this somewhere persistent.

## 4. Project structure

```
trooze-ai/
  server.js                 # Express entry point
  routes/
    analyze.js               # POST /api/analyze/text and /api/analyze/image
    report.js                 # POST/GET /api/report - share links + PDF export
  services/
    groq.js                  # Groq chat-completions wrapper
    analysisEngine.js         # Orchestrates everything into one verdict
    wayback.js                # web.archive.org edit-history diff
    wikipedia.js               # Wikipedia background context
    reverseImage.js            # Reverse image search (assisted manual check - see note below)
    spreadVelocity.js          # Cross-platform spread graph (GDELT, free)
    reportStore.js             # In-memory share-link store (7-day expiry)
    pdfReport.js                # PDF report generation (pdfkit)
  public/
    index.html, style.css      # Main app shell
    render.js                   # Shared result-rendering logic (used by app.js and report.html)
    app.js                       # Input handling, calls the analyze API
    report.html                   # Read-only shared-report viewer page
```

## 5. Swapping models

Groq's model lineup changes fairly often. If a model in `.env` gets
deprecated, check `console.groq.com/docs/models` and update:

```
GROQ_TEXT_MODEL=openai/gpt-oss-120b
GROQ_VISION_MODEL=qwen/qwen3.6-27b
```

## 6. Security note

`.env` is already covered by a `.gitignore` — never commit it, and
never paste its contents into a chat, issue, or screenshot.
