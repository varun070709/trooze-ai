const express = require("express");
const multer = require("multer");
const { analyzeText, analyzeImage } = require("../services/analysisEngine");

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 } // 8MB
});

// Text (or pasted-in article) analysis
router.post("/analyze/text", async (req, res) => {
  try {
    const { text, sourceUrl } = req.body;
    if (!text || !text.trim()) {
      return res.status(400).json({ error: "Missing 'text' in request body." });
    }
    const result = await analyzeText({ text, sourceUrl });
    res.json(result);
  } catch (err) {
    handleError(res, err);
  }
});

// Image (photo/screenshot of an article) analysis
router.post("/analyze/image", upload.single("image"), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "Missing 'image' file upload." });
    }
    const { sourceUrl, imageUrl } = req.body;
    const base64Image = req.file.buffer.toString("base64");

    const result = await analyzeImage({
      base64Image,
      mimeType: req.file.mimetype,
      sourceUrl,
      imageUrl // optional public URL, needed for live reverse-image search
    });
    res.json(result);
  } catch (err) {
    handleError(res, err);
  }
});

function handleError(res, err) {
  console.error(err);
  if (err.code === "NO_API_KEY") {
    return res.status(500).json({ error: err.message });
  }
  res.status(500).json({ error: "Analysis failed. " + (err.message || "") });
}

module.exports = router;
