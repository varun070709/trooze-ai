const express = require("express");
const reportStore = require("../services/reportStore");
const { generatePdfBuffer } = require("../services/pdfReport");

const router = express.Router();

// Save an analysis result and get back a short-lived shareable link.
router.post("/report", (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== "object") {
      return res.status(400).json({ error: "Missing report data." });
    }
    const id = reportStore.save(data);
    res.json({ id, shareUrl: `/report/${id}` });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not create share link." });
  }
});

// Fetch a previously saved report as JSON (used by the /report/:id page).
router.get("/report/:id", (req, res) => {
  const data = reportStore.get(req.params.id);
  if (!data) {
    return res.status(404).json({ error: "This report link has expired or doesn't exist." });
  }
  res.json(data);
});

// Generate a PDF directly from a posted analysis result (no save required -
// used by the "Export PDF" button on a fresh, unsaved result).
router.post("/report/pdf", async (req, res) => {
  try {
    const data = req.body;
    if (!data || typeof data !== "object") {
      return res.status(400).json({ error: "Missing report data." });
    }
    const buffer = await generatePdfBuffer(data);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", "attachment; filename=trooze-ai-report.pdf");
    res.send(buffer);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not generate PDF." });
  }
});

// Generate a PDF from an already-saved report by id.
router.get("/report/:id/pdf", async (req, res) => {
  const data = reportStore.get(req.params.id);
  if (!data) {
    return res.status(404).json({ error: "This report link has expired or doesn't exist." });
  }
  try {
    const buffer = await generatePdfBuffer(data);
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", "attachment; filename=trooze-ai-report.pdf");
    res.send(buffer);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not generate PDF." });
  }
});

module.exports = router;
