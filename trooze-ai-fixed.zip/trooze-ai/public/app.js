const state = { activeTab: "text", imageFile: null };

const els = {
  tabs: document.querySelectorAll(".tab"),
  panelText: document.getElementById("panel-text"),
  panelImage: document.getElementById("panel-image"),
  articleText: document.getElementById("articleText"),
  sourceUrlText: document.getElementById("sourceUrlText"),
  sourceUrlImg: document.getElementById("sourceUrlImg"),
  imagePublicUrl: document.getElementById("imagePublicUrl"),
  dropzone: document.getElementById("dropzone"),
  dropzoneInner: document.getElementById("dropzoneInner"),
  imageInput: document.getElementById("imageInput"),
  imagePreview: document.getElementById("imagePreview"),
  analyzeBtn: document.getElementById("analyzeBtn"),
  errorMsg: document.getElementById("errorMsg"),
  emptyState: document.getElementById("emptyState"),
  loadingState: document.getElementById("loadingState"),
  loadingLabel: document.getElementById("loadingLabel"),
  resultContent: document.getElementById("resultContent")
};

// ---- tabs ----
els.tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    els.tabs.forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    state.activeTab = tab.dataset.tab;
    els.panelText.classList.toggle("hidden", state.activeTab !== "text");
    els.panelImage.classList.toggle("hidden", state.activeTab !== "image");
  });
});

// ---- image dropzone ----
els.dropzone.addEventListener("click", () => els.imageInput.click());
els.imageInput.addEventListener("change", (e) => handleFile(e.target.files[0]));
["dragover", "dragleave", "drop"].forEach((evt) => {
  els.dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    els.dropzone.classList.toggle("drag-over", evt === "dragover");
  });
});
els.dropzone.addEventListener("drop", (e) => handleFile(e.dataTransfer.files[0]));

function handleFile(file) {
  if (!file || !file.type.startsWith("image/")) return;
  state.imageFile = file;
  const reader = new FileReader();
  reader.onload = (e) => {
    els.imagePreview.src = e.target.result;
    els.imagePreview.classList.remove("hidden");
    els.dropzoneInner.classList.add("hidden");
  };
  reader.readAsDataURL(file);
}

// ---- analyze ----
els.analyzeBtn.addEventListener("click", runAnalysis);

const LOADING_MESSAGES = [
  "Extracting claims…",
  "Cross-referencing Wikipedia…",
  "Checking web.archive.org for silent edits…",
  "Scanning for conflict-of-interest signals…",
  "Estimating cross-platform spread…",
  "Writing out the reasoning trace…"
];

async function runAnalysis() {
  hideError();
  const isImage = state.activeTab === "image";

  if (isImage && !state.imageFile) return showError("Please upload an image first.");
  if (!isImage && !els.articleText.value.trim())
    return showError("Please paste some article text or a claim first.");

  setLoading(true);

  try {
    let data;
    if (isImage) {
      const form = new FormData();
      form.append("image", state.imageFile);
      if (els.sourceUrlImg.value.trim()) form.append("sourceUrl", els.sourceUrlImg.value.trim());
      if (els.imagePublicUrl.value.trim()) form.append("imageUrl", els.imagePublicUrl.value.trim());
      const res = await fetch("/api/analyze/image", { method: "POST", body: form });
      data = await res.json();
      if (!res.ok) throw new Error(data.error || "Analysis failed.");
    } else {
      const body = { text: els.articleText.value.trim() };
      if (els.sourceUrlText.value.trim()) body.sourceUrl = els.sourceUrlText.value.trim();
      const res = await fetch("/api/analyze/text", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
      data = await res.json();
      if (!res.ok) throw new Error(data.error || "Analysis failed.");
    }
    els.emptyState.classList.add("hidden");
    window.TroozeRender.renderInto(els.resultContent, data, { showShare: true });
  } catch (err) {
    showError(err.message || "Something went wrong.");
  } finally {
    setLoading(false);
  }
}

function setLoading(isLoading) {
  els.analyzeBtn.disabled = isLoading;
  els.loadingState.classList.toggle("hidden", !isLoading);
  if (isLoading) {
    els.emptyState.classList.add("hidden");
    els.resultContent.classList.add("hidden");
    let i = 0;
    els.loadingLabel.textContent = LOADING_MESSAGES[0];
    state._loadingInterval = setInterval(() => {
      i = (i + 1) % LOADING_MESSAGES.length;
      els.loadingLabel.textContent = LOADING_MESSAGES[i];
    }, 1400);
  } else {
    clearInterval(state._loadingInterval);
  }
}

function showError(msg) {
  els.errorMsg.textContent = msg;
  els.errorMsg.classList.remove("hidden");
}
function hideError() {
  els.errorMsg.classList.add("hidden");
}
