// Shared result-rendering logic, used by both app.js (live analysis) and
// report.js (viewing a saved/shared report). Exposes window.TroozeRender.
(function () {
  function verdictClass(verdict) {
    if (!verdict) return "verdict-mixed";
    const v = verdict.toUpperCase();
    if (v.includes("TRUE")) return "verdict-true";
    if (v.includes("FALSE")) return "verdict-false";
    return "verdict-mixed";
  }

  function renderInto(container, data, opts = {}) {
    const vClass = verdictClass(data.verdict);
    const showShare = opts.showShare !== false;

    container.classList.remove("hidden");
    container.innerHTML = `
      <div class="verdict-card ${vClass}">
        <div class="verdict-top">
          <div>
            <div class="verdict-label">${escapeHtml(data.verdict || "UNVERIFIED")}</div>
            <div class="confidence-chip">Confidence: ${escapeHtml(data.confidence || "n/a")}</div>
          </div>
          <div class="score-dial">
            <div class="score-num">${data.truthScore ?? "–"}</div>
            <div class="score-cap">TRUTH SCORE / 100</div>
          </div>
        </div>
        <p class="verdict-summary">${escapeHtml(data.summary || "")}</p>
        ${
          showShare
            ? `<div class="share-row">
                <button class="share-btn" id="exportPdfBtn">⬇ Export PDF</button>
                <button class="share-btn" id="shareLinkBtn">🔗 Copy share link</button>
                <span class="share-status" id="shareStatus"></span>
              </div>`
            : ""
        }
      </div>

      <div class="module-grid">
        ${renderReasoningTrace(data.reasoningTrace)}
        ${renderKeyClaims(data.keyClaims)}
        ${renderRedFlags(data.redFlags)}
        ${renderWhoBenefits(data.whoBenefits)}
        ${renderManipulation(data.manipulationTechniques)}
        ${renderSources(data.supportingOrRefutingSources)}
        ${renderWikipedia(data.wikipediaContext)}
        ${renderWayback(data.wayback)}
        ${renderSpread(data.spread)}
      </div>
    `;

    if (showShare) wireShareButtons(data);
  }

  function wireShareButtons(data) {
    const statusEl = document.getElementById("shareStatus");
    const pdfBtn = document.getElementById("exportPdfBtn");
    const linkBtn = document.getElementById("shareLinkBtn");

    pdfBtn.addEventListener("click", async () => {
      setStatus("Generating PDF…");
      try {
        const res = await fetch("/api/report/pdf", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        });
        if (!res.ok) throw new Error("PDF generation failed.");
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "trooze-ai-report.pdf";
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
        setStatus("PDF downloaded ✓");
      } catch (err) {
        setStatus(err.message || "Could not generate PDF.");
      }
    });

    linkBtn.addEventListener("click", async () => {
      setStatus("Creating share link…");
      try {
        const res = await fetch("/api/report", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(data)
        });
        const result = await res.json();
        if (!res.ok) throw new Error(result.error || "Could not create share link.");
        const fullUrl = `${window.location.origin}${result.shareUrl}`;
        await navigator.clipboard.writeText(fullUrl).catch(() => {});
        setStatus("Link copied — expires in 7 days");
      } catch (err) {
        setStatus(err.message || "Could not create share link.");
      }
    });

    function setStatus(msg) {
      statusEl.textContent = msg;
    }
  }

  function renderReasoningTrace(trace) {
    if (!trace || !trace.length) return "";
    return `
      <div class="module full">
        <div class="module-title"><span class="dot"></span>Why this score — reasoning trace</div>
        <ol class="reasoning-list">
          ${trace.map((step) => `<li>${escapeHtml(step)}</li>`).join("")}
        </ol>
      </div>`;
  }

  function renderKeyClaims(claims) {
    if (!claims || !claims.length) return "";
    return `
      <div class="module full">
        <div class="module-title"><span class="dot"></span>Key claims checked</div>
        ${claims
          .map(
            (c) => `
          <div class="claim-item">
            <div class="claim-text">${escapeHtml(c.claim)}</div>
            <div class="claim-assess">${escapeHtml(c.assessment)}</div>
          </div>`
          )
          .join("")}
      </div>`;
  }

  function renderRedFlags(flags) {
    if (!flags || !flags.length) return "";
    return `
      <div class="module">
        <div class="module-title"><span class="dot"></span>Red flags</div>
        <div class="tag-list">
          ${flags.map((f) => `<span class="tag red">${escapeHtml(f)}</span>`).join("")}
        </div>
      </div>`;
  }

  function renderManipulation(list) {
    if (!list || !list.length) return "";
    return `
      <div class="module">
        <div class="module-title"><span class="dot"></span>Manipulation techniques</div>
        <div class="tag-list">
          ${list.map((f) => `<span class="tag amber">${escapeHtml(f)}</span>`).join("")}
        </div>
      </div>`;
  }

  function renderWhoBenefits(wb) {
    if (!wb) return "";
    return `
      <div class="module">
        <div class="module-title"><span class="dot"></span>Who benefits / incentive bias</div>
        ${
          wb.flagged
            ? `<div class="tag-list" style="margin-bottom:10px;">${(wb.parties || [])
                .map((p) => `<span class="tag amber">${escapeHtml(p)}</span>`)
                .join("")}</div><p class="mono-note">${escapeHtml(wb.explanation || "")}</p>`
            : `<p class="mono-note">No clear conflict-of-interest pattern detected.</p>`
        }
      </div>`;
  }

  function renderSources(sources) {
    if (!sources || !sources.length) return "";
    return `
      <div class="module full">
        <div class="module-title"><span class="dot"></span>Supporting / refuting sources</div>
        ${sources
          .map((s) => {
            const cls =
              s.stance === "supports" ? "stance-supports" : s.stance === "refutes" ? "stance-refutes" : "stance-context";
            return `
          <div class="source-item">
            <div><strong>${escapeHtml(s.name)}</strong><br/><span class="mono-note">${escapeHtml(s.reason || "")}</span></div>
            <span class="stance-badge ${cls}">${escapeHtml(s.stance || "")}</span>
          </div>`;
          })
          .join("")}
      </div>`;
  }

  function renderWikipedia(wiki) {
    if (!wiki || !wiki.length) return "";
    return `
      <div class="module">
        <div class="module-title"><span class="dot"></span>Background context</div>
        <div class="link-row">
          ${wiki
            .map((w) => `<a href="${w.url}" target="_blank" rel="noopener">${escapeHtml(w.title)} ↗</a>`)
            .join("")}
        </div>
      </div>`;
  }

  function renderWayback(wb) {
    const title = `<div class="module-title"><span class="dot"></span>Edit history (web.archive.org)</div>`;
    if (!wb) {
      return `<div class="module">${title}<p class="mono-note">No article URL was provided, so edit history could not be checked.</p></div>`;
    }
    if (!wb.hasHistory) {
      return `<div class="module">${title}<p class="mono-note">No archived snapshots found for this URL yet.</p></div>`;
    }
    return `
      <div class="module full">
        ${title}
        <p class="mono-note">${wb.snapshotCount} snapshot(s) found. First captured <strong>${wb.firstCapturedAt}</strong>, most recent <strong>${wb.lastCapturedAt}</strong>.</p>
        ${
          wb.firstText && wb.lastText
            ? `<div class="diff-block">
                <div class="diff-col"><span class="diff-title">First capture</span>${escapeHtml(wb.firstText.slice(0, 500))}…</div>
                <div class="diff-col"><span class="diff-title">Latest capture</span>${escapeHtml(wb.lastText.slice(0, 500))}…</div>
              </div>`
            : ""
        }
        <div class="link-row">
          <a href="${wb.firstSnapshotUrl}" target="_blank" rel="noopener">View earliest snapshot ↗</a>
          <a href="${wb.lastSnapshotUrl}" target="_blank" rel="noopener">View latest snapshot ↗</a>
        </div>
      </div>`;
  }

  function renderReverseImage(ri) { return ""; }

  function renderSpread(spread) {
    if (!spread || spread.mode !== "live") {
      return "";
    }

    const badge = '<span class="mode-badge live">LIVE (GDELT)</span>';

    if (!spread.points || !spread.points.length) {
      return "";
    }

    const max = Math.max(...spread.points.map((p) => p.count), 0.01);
    const w = 280,
      h = 90,
      step = w / Math.max(spread.points.length - 1, 1);
    const pts = spread.points
      .map((p, i) => `${(i * step).toFixed(1)},${(h - (p.count / max) * (h - 10) - 5).toFixed(1)}`)
      .join(" ");
    const peak = spread.points.reduce((a, b) => (b.count > a.count ? b : a), spread.points[0]);

    return `
      <div class="module full">
        <div class="module-title"><span class="dot"></span>Spread velocity${badge}</div>
        <p class="mono-note">Global news volume share over the last 7 days (GDELT). Peak: <strong>${peak.date}</strong> (${peak.count.toFixed(2)}% of monitored coverage that day).</p>
        <svg class="spread-chart" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
          <polyline points="${pts}" fill="none" stroke="var(--accent)" stroke-width="2"/>
        </svg>
      </div>`;
  }

  function escapeHtml(str) {
    if (str === null || str === undefined) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  window.TroozeRender = { renderInto, verdictClass };
})();
